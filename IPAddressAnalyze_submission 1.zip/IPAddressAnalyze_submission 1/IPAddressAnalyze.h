/*
 *      Author: ELIYA HONEST
 *
 *      Registration Number: 24022318911
 *      ITT 05213 - Assignment III: Analyzing IP Addresses
 *
 *      NOTE: No STL containers or algorithms are used anywhere in this
 *      file or IPAddressAnalyze.cpp, per the assignment's "no STL" rule.
 *      All data structures (hash table, dynamic array) are hand-written
 *      using plain arrays/malloc/realloc, and sorting uses C's qsort().
 */

#ifndef IPADDRESSANALYZE_H_
#define IPADDRESSANALYZE_H_

#include <iostream>
#include <fstream>
#include <limits.h>
#include <math.h>
#include <unistd.h>
#include <cstdint>
#include "./util/GetMemUsage.h"
#include "./util/LogManager.h"

class IPAddressAnalyzer{

	/**
	 * Parses a dotted-decimal IPv4 string (e.g. "192.168.1.1") into a packed
	 * 32-bit integer so it can be stored/compared cheaply. Comparing the
	 * packed integers is equivalent to comparing the IP addresses
	 * numerically octet-by-octet.
	 * Returns false if ipStr is not a valid IPv4 address (wrong number of
	 * octets, out-of-range octet, or trailing garbage).
	 */
	static bool parseIPToUint32(const char* ipStr, uint32_t &outIp);

	/**
	 * Reconstructs the dotted-decimal string representation of a packed IP
	 * into the caller-supplied buffer, for writing to the output file.
	 */
	static void uint32ToIPString(uint32_t ip, char* outBuf, size_t bufSize);

	/**
	 * Parses a single raw log line of the form "<ip>, <count>". The line
	 * buffer is modified in place (null terminators inserted) rather than
	 * being copied into a heap-allocated string object.
	 * Returns false (meaning: skip this line) if the line is blank, has no
	 * comma, has an empty IP/count field, the IP is not a valid IPv4
	 * address, or the count is not a valid non-negative integer.
	 * On success, ip and count are populated with the parsed values.
	 */
	static bool parseLine(char* line, uint32_t &ip, uint64_t &count);

public:
	/**
	 *
	 *
	 * @param inputFilePath Path of the input file.
	 * @param outputFilePath Path of the output file.
	 * @param topN Number of
	 *
	 * If the input file cannot be read throw an error of type ios_base::failure
	 * If the output file cannot be generated, then throw an error of type ios_base::failure
	 */
	static void getMostFrequentIPAddress(char* inputFilePath, char* outputFilePath, int n);
};

#endif /* IPADDRESSANALYZE_H_ */
