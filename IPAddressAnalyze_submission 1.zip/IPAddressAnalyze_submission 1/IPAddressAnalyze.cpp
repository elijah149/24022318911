/*
 *      Author: ELIYA HONEST
 *
 *      Registration Number: 24022318911
 *      ITT 05213 - Assignment III: Analyzing IP Addresses
 */
#include "IPAddressAnalyze.h"
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <fcntl.h>

// ---------------------------------------------------------------------
// Hand-written hash table: uint32_t IP -> uint32_t total request count.
// (uint32_t is enough headroom for any realistic per-IP total in this
// assignment; the handout explicitly says handling true overflow beyond
// that is not required. We still clamp on add instead of silently
// wrapping, just to be safe.)
//
// Layout is struct-of-arrays with a bit-packed "used" flag array instead
// of one bool per slot -- this roughly halves memory versus a naive
// array-of-structs layout (which pays 24 bytes/slot to alignment
// padding). Open addressing, linear probing, doubling growth. No STL.
// ---------------------------------------------------------------------
namespace {

struct IPHashTable {
	uint32_t* ips;
	uint32_t* counts;
	uint8_t*  usedBits; // 1 bit per slot, packed
	size_t capacity;    // always a power of two
	size_t size;        // number of used slots
	size_t growThreshold; // size at which the next insert triggers a grow
};

static inline bool bitGet(const uint8_t* bits, size_t idx){
	return (bits[idx >> 3] >> (idx & 7)) & 1u;
}
static inline void bitSet(uint8_t* bits, size_t idx){
	bits[idx >> 3] |= (uint8_t)(1u << (idx & 7));
}

// Simple multiplicative hash (Knuth) on the packed IP value.
static inline size_t hashIP(uint32_t ip, size_t capacityMask){
	uint32_t h = ip * 2654435761u;
	return (size_t)h & capacityMask;
}

static void htInit(IPHashTable &ht, size_t initialCapacity){
	ht.capacity = initialCapacity;
	ht.size = 0;
	ht.growThreshold = (ht.capacity * 8) / 10;
	ht.ips = (uint32_t*)malloc(sizeof(uint32_t) * ht.capacity);
	ht.counts = (uint32_t*)malloc(sizeof(uint32_t) * ht.capacity);
	size_t bitmapBytes = (ht.capacity + 7) / 8;
	ht.usedBits = (uint8_t*)calloc(bitmapBytes, 1);
	if (!ht.ips || !ht.counts || !ht.usedBits){
		throw std::runtime_error("Memory allocation failed while creating hash table.");
	}
}

static void htFree(IPHashTable &ht){
	free(ht.ips);
	free(ht.counts);
	free(ht.usedBits);
	ht.ips = nullptr;
	ht.counts = nullptr;
	ht.usedBits = nullptr;
	ht.capacity = 0;
	ht.size = 0;
}

// Inserts a brand-new (guaranteed unique) key during a rehash.
static void htInsertUnique(IPHashTable &ht, uint32_t ip, uint32_t count){
	size_t mask = ht.capacity - 1;
	size_t idx = hashIP(ip, mask);
	while (bitGet(ht.usedBits, idx)){
		idx = (idx + 1) & mask;
	}
	ht.ips[idx] = ip;
	ht.counts[idx] = count;
	bitSet(ht.usedBits, idx);
}

static void htGrow(IPHashTable &ht){
	IPHashTable bigger;
	htInit(bigger, ht.capacity * 2);
	for (size_t i = 0; i < ht.capacity; i++){
		if (bitGet(ht.usedBits, i)){
			htInsertUnique(bigger, ht.ips[i], ht.counts[i]);
		}
	}
	bigger.size = ht.size;
	htFree(ht);
	ht = bigger;
}

// Adds delta to the running total for ip, creating a new slot if needed.
// Grows the table (doubling) once the load factor would exceed ~0.8.
static inline __attribute__((always_inline)) void htAddOrIncrement(IPHashTable &ht, uint32_t ip, uint32_t delta){
	if (ht.size >= ht.growThreshold){
		htGrow(ht);
	}
	size_t mask = ht.capacity - 1;
	size_t idx = hashIP(ip, mask);
	while (bitGet(ht.usedBits, idx)){
		if (ht.ips[idx] == ip){
			uint64_t newVal = (uint64_t)ht.counts[idx] + (uint64_t)delta;
			ht.counts[idx] = (newVal > 0xFFFFFFFFu) ? 0xFFFFFFFFu : (uint32_t)newVal;
			return;
		}
		idx = (idx + 1) & mask;
	}
	ht.ips[idx] = ip;
	ht.counts[idx] = delta;
	bitSet(ht.usedBits, idx);
	ht.size++;
}

// ---------------------------------------------------------------------
// Manual dynamic array of (ip, count) pairs, used for the small "top-N
// qualifying" subset that gets sorted and written out.
// ---------------------------------------------------------------------
struct QualEntry {
	uint32_t ip;
	uint32_t count;
};

struct QualArray {
	QualEntry* items;
	size_t size;
	size_t capacity;
};

static void qaInit(QualArray &qa, size_t initialCapacity){
	qa.capacity = initialCapacity > 0 ? initialCapacity : 16;
	qa.size = 0;
	qa.items = (QualEntry*)malloc(sizeof(QualEntry) * qa.capacity);
	if (!qa.items){
		throw std::runtime_error("Memory allocation failed while creating qualifying array.");
	}
}

static void qaFree(QualArray &qa){
	free(qa.items);
	qa.items = nullptr;
	qa.size = 0;
	qa.capacity = 0;
}

static void qaPush(QualArray &qa, uint32_t ip, uint32_t count){
	if (qa.size == qa.capacity){
		size_t newCapacity = qa.capacity * 2;
		QualEntry* grown = (QualEntry*)realloc(qa.items, sizeof(QualEntry) * newCapacity);
		if (!grown){
			throw std::runtime_error("Memory allocation failed while growing qualifying array.");
		}
		qa.items = grown;
		qa.capacity = newCapacity;
	}
	qa.items[qa.size].ip = ip;
	qa.items[qa.size].count = count;
	qa.size++;
}

// Comparator for qsort: count descending, then IP ascending for ties.
static int compareQualEntries(const void* a, const void* b){
	const QualEntry* ea = (const QualEntry*)a;
	const QualEntry* eb = (const QualEntry*)b;
	if (ea->count != eb->count){
		return (ea->count > eb->count) ? -1 : 1; // descending by count
	}
	if (ea->ip != eb->ip){
		return (ea->ip < eb->ip) ? -1 : 1; // ascending by ip
	}
	return 0;
}

// Trims leading/trailing spaces, tabs, CR, LF from a [start, end) range by
// moving the pointers inward. Operates on read-only memory (no mutation),
// which lets us parse straight out of a memory-mapped file.
static inline __attribute__((always_inline)) void trimRange(const char* &start, const char* &end){
	while (start < end && (*start == ' ' || *start == '\t')) start++;
	while (end > start){
		char c = end[-1];
		if (c == ' ' || c == '\t' || c == '\r' || c == '\n') end--;
		else break;
	}
}

// Parses a bounded (non-null-terminated) dotted-decimal IPv4 range into a
// packed 32-bit integer. Returns false if not a clean IPv4 address.
static inline __attribute__((always_inline)) bool parseIPBounded(const char* p, const char* end, uint32_t &outIp){
	unsigned int octets[4];
	for (int i = 0; i < 4; i++){
		if (p >= end || *p < '0' || *p > '9') return false;
		unsigned int val = (unsigned int)(*p - '0');
		p++;
		if (p < end && *p >= '0' && *p <= '9'){
			val = val * 10 + (unsigned int)(*p - '0');
			p++;
			if (p < end && *p >= '0' && *p <= '9'){
				val = val * 10 + (unsigned int)(*p - '0');
				p++;
				if (p < end && *p >= '0' && *p <= '9') return false; // 4th digit: always invalid
			}
		}
		if (val > 255) return false;
		octets[i] = val;
		if (i < 3){
			if (p >= end || *p != '.') return false;
			p++;
		}
	}
	if (p != end) return false; // leftover garbage
	outIp = ((uint32_t)octets[0] << 24) | ((uint32_t)octets[1] << 16)
			| ((uint32_t)octets[2] << 8) | (uint32_t)octets[3];
	return true;
}

// Parses a bounded (non-null-terminated) non-negative integer range.
// Clamps to UINT32_MAX on overflow rather than wrapping.
static inline __attribute__((always_inline)) bool parseCountBounded(const char* p, const char* end, uint32_t &outVal){
	if (p >= end || *p < '0' || *p > '9') return false;
	uint64_t val = 0;
	const char* start = p;
	while (p < end && *p >= '0' && *p <= '9'){
		val = val * 10 + (uint64_t)(*p - '0');
		if (val > 0xFFFFFFFFu) val = 0xFFFFFFFFu;
		p++;
	}
	if (p == start) return false;
	if (p != end) return false; // leftover non-digit garbage
	outVal = (uint32_t)val;
	return true;
}

} // anonymous namespace

// These two are kept as declared private helpers (used by nothing else,
// but documented in the header) so the small self-contained IP parsing /
// formatting logic stays easy to unit-test in isolation if needed.
bool IPAddressAnalyzer::parseIPToUint32(const char* ipStr, uint32_t &outIp){
	size_t len = strlen(ipStr);
	return parseIPBounded(ipStr, ipStr + len, outIp);
}

void IPAddressAnalyzer::uint32ToIPString(uint32_t ip, char* outBuf, size_t bufSize){
	snprintf(outBuf, bufSize, "%u.%u.%u.%u",
			(ip >> 24) & 0xFFu, (ip >> 16) & 0xFFu, (ip >> 8) & 0xFFu, ip & 0xFFu);
}

bool IPAddressAnalyzer::parseLine(char* line, uint32_t &ip, uint64_t &count){
	// Retained for interface compatibility; the hot path in
	// getMostFrequentIPAddress parses directly from the memory-mapped
	// file instead of calling this per line.
	char* comma = strchr(line, ',');
	if (!comma) return false;
	const char* ipStart = line;
	const char* ipEnd = comma;
	const char* cntStart = comma + 1;
	const char* cntEnd = line + strlen(line);
	trimRange(ipStart, ipEnd);
	trimRange(cntStart, cntEnd);
	if (ipStart == ipEnd || cntStart == cntEnd) return false;
	uint32_t parsedCount;
	if (!parseIPBounded(ipStart, ipEnd, ip)) return false;
	if (!parseCountBounded(cntStart, cntEnd, parsedCount)) return false;
	count = parsedCount;
	return true;
}

void IPAddressAnalyzer::getMostFrequentIPAddress(char* inputFilePath, char* outputFilePath, int n){
	int fd = open(inputFilePath, O_RDONLY);
	if (fd < 0){
		char message[1024];
		sprintf(message, "Cannot open input file for reading: %s", inputFilePath);
		throw std::ios_base::failure(message);
	}

	FILE* outFileStream = fopen(outputFilePath, "w");
	if (! outFileStream){
		close(fd);
		char message[1024];
		sprintf(message, "Cannot open output file for writing: %s", outputFilePath);
		throw std::ios_base::failure(message);
	}

	LogManager::writePrintfToLog(LogManager::Level::Status,
			"IPAddressAnalyzer::getMostFrequentIPAddress",
			"Starting to process file %s", inputFilePath);

	// --- Phase 1: stream the input file through a small fixed-size buffer,
	//     splitting lines with memchr and parsing numbers by hand (no
	//     getline, no strtol/strtoll, no whole-file mmap). This keeps
	//     memory bounded to one buffer regardless of file size while still
	//     avoiding the per-line syscall/allocation overhead of getline.
	//     This is the only pass that touches every line, so it dominates
	//     run time for large logs and is the one pass worth hand-tuning.
	IPHashTable ht;
	// Pre-sized for the assignment's own stated scale ("100K or more IP
	// addresses" - see handout). This avoids ever needing to grow/rehash
	// for realistic inputs, which removes the transient "old + new table
	// both allocated at once" memory spike a doubling grow would cause.
	// Smaller inputs just end up with some unused capacity; growth logic
	// below still kicks in safely if an input exceeds this.
	htInit(ht, 1 << 18);

	size_t bufCapacity = 1 << 19; // 512 KiB streaming chunk
	char* buf = (char*)malloc(bufCapacity);
	if (!buf){
		close(fd);
		htFree(ht);
		fclose(outFileStream);
		throw std::runtime_error("Memory allocation failed while creating read buffer.");
	}
	size_t bufLen = 0; // valid bytes currently sitting in buf

	while (true){
		ssize_t bytesRead = read(fd, buf + bufLen, bufCapacity - bufLen);
		if (bytesRead < 0){
			free(buf);
			close(fd);
			htFree(ht);
			fclose(outFileStream);
			char message[1024];
			sprintf(message, "Cannot open input file for reading: %s", inputFilePath);
			throw std::ios_base::failure(message);
		}

		if (bytesRead == 0){
			// EOF: whatever remains in buf is a final line with no
			// trailing newline (or nothing at all).
			if (bufLen > 0){
				const char* ipStart = buf;
				const char* ipEnd = nullptr;
				const char* lineEnd = buf + bufLen;
				const char* comma = (const char*)memchr(buf, ',', bufLen);
				if (comma){
					ipEnd = comma;
					const char* cntStart = comma + 1;
					const char* cntEnd = lineEnd;
					trimRange(ipStart, ipEnd);
					trimRange(cntStart, cntEnd);
					if (ipStart != ipEnd && cntStart != cntEnd){
						uint32_t parsedIp, parsedCount;
						if (parseIPBounded(ipStart, ipEnd, parsedIp)
								&& parseCountBounded(cntStart, cntEnd, parsedCount)){
							htAddOrIncrement(ht, parsedIp, parsedCount);
						}
					}
				}
			}
			break;
		}

		bufLen += (size_t)bytesRead;

		// Process every complete line currently in the buffer.
		char* lineStart = buf;
		char* bufEnd = buf + bufLen;
		while (true){
			char* nl = (char*)memchr(lineStart, '\n', (size_t)(bufEnd - lineStart));
			if (!nl) break;

			const char* comma = (const char*)memchr(lineStart, ',', (size_t)(nl - lineStart));
			if (comma){
				const char* ipStart = lineStart;
				const char* ipEnd = comma;
				const char* cntStart = comma + 1;
				const char* cntEnd = nl;
				trimRange(ipStart, ipEnd);
				trimRange(cntStart, cntEnd);
				if (ipStart != ipEnd && cntStart != cntEnd){
					uint32_t parsedIp, parsedCount;
					if (parseIPBounded(ipStart, ipEnd, parsedIp)
							&& parseCountBounded(cntStart, cntEnd, parsedCount)){
						htAddOrIncrement(ht, parsedIp, parsedCount);
					}
				}
			}

			lineStart = nl + 1;
		}

		// Shift the trailing partial line (if any) to the front of buf.
		size_t remainder = (size_t)(bufEnd - lineStart);
		if (lineStart != buf && remainder > 0){
			memmove(buf, lineStart, remainder);
		}
		bufLen = remainder;

		// Extremely long single line (rare): grow the buffer.
		if (bufLen == bufCapacity){
			size_t newCapacity = bufCapacity * 2;
			char* grown = (char*)realloc(buf, newCapacity);
			if (!grown){
				free(buf);
				close(fd);
				htFree(ht);
				fclose(outFileStream);
				throw std::runtime_error("Memory allocation failed while growing read buffer.");
			}
			buf = grown;
			bufCapacity = newCapacity;
		}
	}

	free(buf);
	close(fd);

	if (n <= 0 || ht.size == 0){
		htFree(ht);
		fflush(outFileStream);
		fclose(outFileStream);
		return;
	}

	// --- Phase 2: find the smallest total among the top-N *distinct*
	//     count values, using a small bounded array of size N (kept
	//     unsorted; N is expected to be tiny compared to the number of
	//     unique IPs, so a linear scan for the current minimum is cheap).
	uint32_t* topCounts = (uint32_t*)malloc(sizeof(uint32_t) * (size_t)n);
	if (!topCounts){
		htFree(ht);
		fclose(outFileStream);
		throw std::runtime_error("Memory allocation failed while tracking top-N counts.");
	}
	int topCountsSize = 0;
	int minIdx = 0;

	for (size_t i = 0; i < ht.capacity; i++){
		if (!bitGet(ht.usedBits, i)) continue;
		uint32_t c = ht.counts[i];

		if (topCountsSize < n){
			// Skip if this distinct value is already tracked.
			bool alreadyTracked = false;
			for (int j = 0; j < topCountsSize; j++){
				if (topCounts[j] == c){ alreadyTracked = true; break; }
			}
			if (alreadyTracked) continue;

			topCounts[topCountsSize] = c;
			if (topCountsSize == 0 || c < topCounts[minIdx]) minIdx = topCountsSize;
			topCountsSize++;
		} else if (c > topCounts[minIdx]){
			bool alreadyTracked = false;
			for (int j = 0; j < topCountsSize; j++){
				if (topCounts[j] == c){ alreadyTracked = true; break; }
			}
			if (alreadyTracked) continue;

			topCounts[minIdx] = c;
			// Re-find the minimum among the tracked values.
			minIdx = 0;
			for (int j = 1; j < topCountsSize; j++){
				if (topCounts[j] < topCounts[minIdx]) minIdx = j;
			}
		}
	}

	uint32_t thresholdCount = topCounts[minIdx];
	free(topCounts);

	// --- Phase 3: collect every IP whose total meets the threshold into a
	//     small dynamic array, then sort just that subset with qsort:
	//     count descending, then IP ascending for ties.
	QualArray qualifying;
	qaInit(qualifying, (size_t)topCountsSize * 4 + 8);

	for (size_t i = 0; i < ht.capacity; i++){
		if (bitGet(ht.usedBits, i) && ht.counts[i] >= thresholdCount){
			qaPush(qualifying, ht.ips[i], ht.counts[i]);
		}
	}
	htFree(ht);

	qsort(qualifying.items, qualifying.size, sizeof(QualEntry), compareQualEntries);

	// --- Phase 4: assign dense ranks (ties share a rank, next rank is
	//     rank+1, not rank+tieCount) and write "rank, ip, count" lines.
	int rank = 0;
	uint32_t prevCount = 0;
	bool first = true;
	char ipStrBuf[16];
	for (size_t i = 0; i < qualifying.size; i++){
		uint32_t c = qualifying.items[i].count;
		if (first || c != prevCount){
			rank++;
			prevCount = c;
			first = false;
		}
		if (rank > n) break;
		uint32ToIPString(qualifying.items[i].ip, ipStrBuf, sizeof(ipStrBuf));
		fprintf(outFileStream, "%d, %s, %u\n", rank, ipStrBuf, c);
	}

	qaFree(qualifying);
	fflush(outFileStream);
	fclose(outFileStream);
}
