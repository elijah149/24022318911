#include "FixationPoints.h"

namespace {

constexpr const char* registrationNumber = "24022318911";
constexpr const char* inputFile = "../data/input.txt";
constexpr const char* outputFile = "../data/output.txt";
constexpr const char* separator = "***************";

}  // namespace

FixationPoints::FixationPoints() {
    for (unsigned int index = 0; index < kBucketCount; ++index) {
        buckets_[index] = nullptr;
    }
}

FixationPoints::~FixationPoints() {
    clear_table();
}

unsigned int FixationPoints::coordinate_key(int x, int y) {
    return static_cast<unsigned int>(x) * kCoordinateRange +
           static_cast<unsigned int>(y);
}

unsigned int FixationPoints::bucket_index(unsigned int key) {
    key ^= key >> 16U;
    key *= 0x7feb352dU;
    key ^= key >> 15U;
    return key % kBucketCount;
}

bool FixationPoints::insert_if_absent(unsigned int key) {
    const unsigned int index = bucket_index(key);
    HashNode* current = buckets_[index];

    // Walk the chain to check if key already exists
    while (current != nullptr) {
        if (current->key == key) {
            return false;  // Already present; not distinct
        }
        current = current->next;
    }

    // Key not found: allocate a new node and prepend to the chain
    HashNode* node = new HashNode;
    node->key = key;
    node->next = buckets_[index];
    buckets_[index] = node;
    return true;  // Successfully inserted; coordinate is distinct
}

void FixationPoints::clear_table() {
    // Free every node in every bucket and reset all bucket pointers
    for (unsigned int index = 0; index < kBucketCount; ++index) {
        HashNode* current = buckets_[index];
        while (current != nullptr) {
            HashNode* next = current->next;
            delete current;
            current = next;
        }
        buckets_[index] = nullptr;
    }
}

int FixationPoints::process_scanpath(FILE* input, FILE* output) {
    clear_table();
    int output_identifier = 1;

    int original_id, x, y;
    // Read fixation points until the sentinel (-1, -1) is encountered
    while (fscanf(input, "%d %d %d", &original_id, &x, &y) == 3) {
        if (x == -1 && y == -1) {
            break;  // End of this scanpath
        }
        unsigned int key = coordinate_key(x, y);
        if (insert_if_absent(key)) {
            // First encounter: write with new contiguous identifier
            fprintf(output, "%d %d %d\n", output_identifier, x, y);
            ++output_identifier;
        }
    }

    // Write the separator line after each scanpath
    fprintf(output, "%s\n", separator);
    return 0;
}

int FixationPoints::process() {
    FILE* input = fopen(inputFile, "r");
    if (input == nullptr) {
        return 1;
    }

    FILE* output = fopen(outputFile, "w");
    if (output == nullptr) {
        fclose(input);
        return 1;
    }

    // Write registration number as the very first line
    fprintf(output, "%s\n", registrationNumber);

    int scanpath_count = 0;
    fscanf(input, "%d", &scanpath_count);

    for (int i = 0; i < scanpath_count; ++i) {
        process_scanpath(input, output);
    }

    fclose(input);
    fclose(output);
    return 0;
}
