#include "FixationPoints.h"

int main() {
    FixationPoints fp;
    return fp.process();
}
