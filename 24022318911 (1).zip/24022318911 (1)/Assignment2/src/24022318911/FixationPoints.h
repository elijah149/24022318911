/*
 * Author: 24022318911
 *
 * Functionality:
 * Read eye-tracker scanpaths and output each distinct fixation coordinate in
 * first-encounter order with contiguous identifiers beginning at one.
 *
 * Input and output:
 * Input is read from ../data/input.txt. The first value is the number of
 * scanpaths. Every fixation-point record contains its original identifier and
 * x/y coordinates. Coordinates -1 -1 terminate a scanpath. Output is written
 * to ../data/output.txt and begins with the registration number.
 *
 * Solution strategy:
 * Pack each coordinate pair into one integer key and store encountered keys in
 * a manually implemented chained hash table. If insertion succeeds, the
 * coordinate is distinct and is written immediately. Clear the table before
 * processing the next scanpath. No STL containers or algorithms are used.
 *
 * Testing summary and test strategy:
 * Tested with all-unique points, repeated and non-consecutive duplicates,
 * same-axis coordinates, boundary coordinates 0 and 2000, multiple scanpaths,
 * ten scanpaths, and maximum-length 1000-point scanpaths.
 *
 * Complexity analysis:
 * For n fixation points and u distinct coordinates, manual hash-table
 * operations give expected O(n) total time and O(u) auxiliary space. O(u)
 * space is necessary for one-pass exact duplicate detection.
 */

#ifndef _FIXATION_POINTS_H
#define _FIXATION_POINTS_H

#include <stdio.h>

class FixationPoints {
public:
    FixationPoints();
    ~FixationPoints();
    int process();

private:
    static constexpr int kCoordinateLimit = 2000;
    static constexpr unsigned int kCoordinateRange = kCoordinateLimit + 1;
    static constexpr unsigned int kBucketCount = 2003;

    struct HashNode {
        unsigned int key;
        HashNode* next;
    };

    static unsigned int coordinate_key(int x, int y);
    static unsigned int bucket_index(unsigned int key);
    bool insert_if_absent(unsigned int key);
    void clear_table();
    int process_scanpath(FILE* input, FILE* output);

    HashNode* buckets_[kBucketCount];
};

#endif
